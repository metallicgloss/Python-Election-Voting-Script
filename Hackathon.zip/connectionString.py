dbHost = ""
dbDatabase = ""
dbUsername = ""
dbPassword = ""